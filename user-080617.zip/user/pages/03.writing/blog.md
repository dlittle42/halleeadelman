---
title: Writing
body_classes: writing
content:
    items: '@self.children'
    limit: 5
    order:
        by: default
        dir: desc
    pagination: true
    url_taxonomy_filters: true
---

