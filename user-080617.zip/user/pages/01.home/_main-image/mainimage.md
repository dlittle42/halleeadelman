---
title: 'Main Image'
published: true
cache_enable: false
---

# Hallee is an author who believes that all children and teens should have opportunities to _imagine boundlessly_, unlock their strengths, and discover their passions.