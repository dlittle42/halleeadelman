---
title: News
body_classes: news
content:
    items: '@self.children'
    limit: '5'
    order:
        by: date
        dir: asc
    pagination: '1'
    url_taxonomy_filters: '1'
---

