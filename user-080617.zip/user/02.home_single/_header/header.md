---
visible: false
cache_enable: false
---
[g-navbar id="navbar2" name=navbar2 fixed=top centering=none brand_text="Gravstrap" render=false]
    [g-navbar-menu name=menu0 alignment="center" onepage=true attributes="class:highdensity-menu"][/g-navbar-menu]
    [g-navbar-menu name=menu1 icon_type="fontawesome" alignment="right" attributes="class:social-menu"]
        [g-link url="https://facebook.com/gravstrap" icon_type="fontawesome" icon="facebook"][/g-link]
        [g-link url="https://twitter.com/gravstrap" icon="twitter"][/g-link]
        [g-link url="https://github.com/giansi/gravstrap" icon="github"][/g-link]
    [/g-navbar-menu]    
[/g-navbar]

[g-jumbotron name="jumbotron1" fullwidth="true" image="bg_home.jpg" render=false]
# Gravstrap theme single page

Gravstrap navbar component can be easily configured to implement an awesome single page web site: use the menu to scroll to each page section

[Download Gravstrap Theme](http://diblas.net/themes/gravstrap-theme-helps-to-start-a-new-grav-cms-site-with-bootstrap-support/how-to-install-gravstrap-theme){.btn .btn-outline-inverse .btn-lg}
[How to build a single page site](http://diblas.net/themes/gravstrap-theme-helps-to-start-a-new-grav-cms-site-with-bootstrap-support/build-single-site-page-with-gravstrap-theme){.btn .btn-outline-inverse .btn-lg}

[/g-jumbotron]
