---
title: Home single
metadata:
  description: You can use the Gravstrap Theme to easily build a single page web site.

slug: gravstrap-theme-simple-page-example

content:
    items: @self.modular
    order:
        by: default
        dir: asc
        custom:
            - _header
            - _what_we_do
            - _portfolio
            - _clients
            - _team
            - _where_we_are
            - _contacts
---
