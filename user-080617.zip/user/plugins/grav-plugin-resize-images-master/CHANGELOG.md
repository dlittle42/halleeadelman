# v0.2.2
##  03/03/2017

1. [](#bugfix)
    * Fixed issue that arose when `system.images.cache_all` was enabled with a more reliable method for determining image source paths.

# v0.2.1
##  03/03/2017

1. [](#new)
    * Added option to enable removing of original image after it has been resized.

# v0.2.0
##  03/03/2017

1. [](#bugfix)
    * Fixed adapter fallback logic and print a warning when no adapter is installed.

# v0.1.0
##  10/14/2016

1. [](#new)
    * Initial release
