---

menu: Team

---

[g-team attributes="id:_team,class:team module"]

## Introduce your awesome team
Use the `Team module` to introduce your awesome team.

___

[g-team-item image="jane.jpg" attributes="class:col-md-4"]
Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
<div class="item-social">
[g-link url="#" icon="twitter" icon_type="fontawesome" stacked=true][/g-link]
[g-link url="#" icon="facebook" icon_type="fontawesome" stacked=true][/g-link]
[g-link url="#" icon="linkedin" icon_type="fontawesome" stacked=true][/g-link]
</div>

[/g-team-item]

[g-team-item image="mark.jpg" attributes="class:col-md-4"]
Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
<div class="item-social">
[g-link url="#" icon="twitter" icon_type="fontawesome" stacked=true][/g-link]
[g-link url="#" icon="facebook" icon_type="fontawesome" stacked=true][/g-link]
[g-link url="#" icon="linkedin" icon_type="fontawesome" stacked=true][/g-link]
</div>

[/g-team-item]

[g-team-item image="julia.jpg" attributes="class:col-md-4"]
Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
<div class="item-social">
[g-link url="#" icon="twitter" icon_type="fontawesome" stacked=true][/g-link]
[g-link url="#" icon="facebook" icon_type="fontawesome" stacked=true][/g-link]
[g-link url="#" icon="linkedin" icon_type="fontawesome" stacked=true][/g-link]
</div>

[/g-team-item]
[/g-team]