---

menu: Clients

---

[g-clients attributes="id:_clients,class:clients module"]

## Show out the clients who trust your business
Use the `Clients module` to show your customers, the clients who already trust your business

___

[g-clients-item image="apple.svg" attributes="class:col-md-3"][/g-clients-item]
[g-clients-item image="canon.svg" attributes="class:col-md-3"][/g-clients-item]
[g-clients-item image="forbes.svg" attributes="class:col-md-3"][/g-clients-item]
[g-clients-item image="hp.svg" attributes="class:col-md-3"][/g-clients-item]
[g-clients-item image="intel.svg" attributes="class:col-md-3"][/g-clients-item]
[g-clients-item image="samsung.svg" attributes="class:col-md-3"][/g-clients-item]
[g-clients-item image="siemens.svg" attributes="class:col-md-3"][/g-clients-item]
[g-clients-item image="vaio.svg" attributes="class:col-md-3"][/g-clients-item]

[/g-clients]