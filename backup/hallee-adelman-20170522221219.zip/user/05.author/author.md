---
title: Author
metadata:
  description: A versatile module to implement an author page
slug: something-about-me
---

# About Me
Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam.

[section name=education]
### Formation

- [2013](#)
  Lorem ipsum.  
  Sed ut perspiciatis unde omnis 
- [2010](#)
  Lorem ipsum.  
  Sed ut perspiciatis unde omnis 
- [2005](#)
  Lorem ipsum.  
  Sed ut perspiciatis unde omnis  
- [2000](#)
  Lorem ipsum.  
  Sed ut perspiciatis unde omnis 
[/section]

[section name=experience]
### Experience

- [2015](#)
  Graphics & Web.  
  Sed ut perspiciatis unde omnis
- [2014](#)
  Graphics & Web.  
  Sed ut perspiciatis unde omnis
- [2013](#)
  Art Director.   
  Sed ut perspiciatis unde omnis
[/section]

[section name=skills]
### Skills

[g-progressbar label="Php" type="success" value="80" min="0" max="100" render=true][/g-progressbar]
[g-progressbar label="Mysql" type="success" value="80" min="0" max="100" render=true][/g-progressbar]
[g-progressbar label="Javascript" type="success" value="90" min="0" max="100" render=true][/g-progressbar]
[g-progressbar label="Jquery" type="success" value="90" min="0" max="100" render=true][/g-progressbar]
[g-progressbar label="Css" type="success" value="90" min="0" max="100" render=true][/g-progressbar]
[g-progressbar label="Photoshop" type="warning" value="60" min="0" max="100" render=true][/g-progressbar]
[g-progressbar label="Git" type="success" value="80" min="0" max="100" render=true][/g-progressbar]
[/section]