---
title: Right column internal template
metadata:
  description: The internal.html.twig template configured to display a single column on the right
slug: right-internal-template

---

[g-section-extended name=main attributes="class:col-md-8"]
# Main contents

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum in porta lacus, vel laoreet magna. Cras vitae sem nec felis luctus sollicitudin. Donec eleifend ullamcorper purus. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Praesent consectetur auctor dui in suscipit. Duis orci metus, iaculis quis faucibus sit amet, hendrerit laoreet nisl. Morbi dignissim tincidunt blandit. Curabitur non egestas nisl, sit amet eleifend neque. Ut a risus id lorem lacinia pellentesque. Morbi ornare est ante, nec euismod ligula laoreet pharetra. Curabitur eu egestas quam. Proin risus ipsum, rutrum eu feugiat id, gravida ut justo. Phasellus laoreet turpis non mi pulvinar, quis viverra lorem egestas. Aliquam scelerisque mauris nec dui viverra molestie. Cras pretium enim ac accumsan molestie. Nulla facilisi.

Cras facilisis sit amet quam eu euismod. Pellentesque mauris ipsum, malesuada et orci a, fermentum tincidunt erat. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Phasellus sit amet efficitur neque, iaculis scelerisque erat. Quisque sit amet hendrerit ex, quis ullamcorper purus. Curabitur volutpat purus et facilisis mattis. Cras nisi nisl, commodo at tellus eget, semper imperdiet justo. In posuere pretium purus, sit amet maximus nisl lobortis efficitur. Fusce massa mi, rutrum eu ligula non, efficitur posuere elit. Nullam arcu metus, rhoncus in ante at, finibus sollicitudin felis. Cras at mollis velit. Etiam ultricies non mauris ac faucibus. Praesent nec justo sed lacus pulvinar pulvinar. Mauris at mi vitae nisi eleifend gravida imperdiet at urna.

Nam in magna at lectus rhoncus suscipit eget et metus. Maecenas porta mauris in massa viverra luctus. Aliquam facilisis porta nisl, quis sagittis diam rutrum a. Proin sed dictum neque, in gravida lorem. Quisque massa neque, facilisis vel sem nec, dapibus suscipit purus. Sed sollicitudin malesuada urna eget ultrices. Phasellus viverra risus et risus porta, eget malesuada nisl elementum.

Donec sit amet ante nulla. Morbi nec diam lorem. Aliquam in efficitur elit. Duis et feugiat nulla. Vestibulum ut ipsum ut elit vehicula auctor. Quisque sagittis purus et tellus cursus efficitur. Duis vel leo ut lorem tincidunt vehicula ac non ipsum. Mauris cursus diam eleifend odio faucibus, vel porta metus malesuada. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Pellentesque sed bibendum lorem, sed bibendum sapien. Phasellus aliquet pulvinar tincidunt. Quisque non pretium mauris, malesuada tempus ligula.
[/g-section-extended]


[g-section-extended name=right attributes="class:col-md-4"]
###Right Sidebar
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum in porta lacus, vel laoreet magna. Cras vitae sem nec felis luctus sollicitudin. Donec eleifend ullamcorper purus. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Praesent consectetur auctor dui in suscipit. Duis orci metus, iaculis quis faucibus sit amet, hendrerit laoreet nisl. Morbi dignissim tincidunt blandit. Curabitur non egestas nisl, sit amet eleifend neque. Ut a risus id lorem lacinia pellentesque. Morbi ornare est ante, nec euismod ligula laoreet pharetra. Curabitur eu egestas quam. Proin risus ipsum, rutrum eu feugiat id, gravida ut justo. Phasellus laoreet turpis non mi pulvinar, quis viverra lorem egestas. Aliquam scelerisque mauris nec dui viverra molestie. Cras pretium enim ac accumsan molestie. Nulla facilisi.

###Another content
Cras facilisis sit amet quam eu euismod. Pellentesque mauris ipsum, malesuada et orci a, fermentum tincidunt erat. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Phasellus sit amet efficitur neque, iaculis scelerisque erat. Quisque sit amet hendrerit ex, quis ullamcorper purus. Curabitur volutpat purus et facilisis mattis. Cras nisi nisl, commodo at tellus eget, semper imperdiet justo. In posuere pretium purus, sit amet maximus nisl lobortis efficitur. Fusce massa mi, rutrum eu ligula non, efficitur posuere elit. Nullam arcu metus, rhoncus in ante at, finibus sollicitudin felis. Cras at mollis velit. Etiam ultricies non mauris ac faucibus. Praesent nec justo sed lacus pulvinar pulvinar. Mauris at mi vitae nisi eleifend gravida imperdiet at urna.
[/g-section-extended]