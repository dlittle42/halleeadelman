---
title: Carousel header
menu: Carousel header
metadata:
  description: The Gravstrap theme home page with carousel header variation.
slug: home-page-with-carousel-header

content:
    items: @self.modular
    order:
        by: default
        dir: asc
        custom:
            - _showcase
            - _what_we_do
            - _portfolio
            - _clients
            - _team
            - _where_we_are
            - _contacts
---

