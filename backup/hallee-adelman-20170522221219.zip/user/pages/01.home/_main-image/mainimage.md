---
title: 'Main Image'
---

Hallee is an author who believes that all children and teens should have opportunities to imagine boundlessly, unlock their strengths, and discover their passions.