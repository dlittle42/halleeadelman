---
title: 'Young President''s Organization'
date: '01-03-2018 23:36'
taxonomy:
    year:
        - '20180301'
header_image: '0'
header_image_height: 450
summary:
    enabled: '0'
    format: long
---

After receiving an international award for chairing a Kids for Kids event for the Young President's Organization (YPO), Hallee will co-chair another YPO event for families. She will be partnering with the Belmont School and the Sixers Youth Foundation. More to come... 