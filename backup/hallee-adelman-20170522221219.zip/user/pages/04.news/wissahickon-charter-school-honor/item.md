---
title: 'Wissahickon Charter School Honor'
date: '13-05-2017 23:24'
taxonomy:
    year:
        - '20170513'
header_image: '0'
summary:
    enabled: '0'
---

[plugin:youtube](https://www.youtube.com/watch?v=BUH20PhuNow)

![](WCSPhoto.jpg?cropResize=300,300){.left-img} On May 13, 2017, Hallee will be honored for her work with students and her efforts to build a school library at WCS in Philadelphia. For more information , [click here](https://www.youtube.com/watch?v=BUH20PhuNow).
