---
visible: false
cache_enable: false
---

[g-navbar id="navbar1" name=navbar1 fixed=top centering=none brand_text="Gravstrap" render=false]
    [g-navbar-menu name=menu0 alignment="center" submenu="internal,components" attributes="class:highdensity-menu"][/g-navbar-menu]    
    [g-navbar-menu name=menu1 icon_type="fontawesome" alignment="right" ]
        [g-link url="https://facebook.com/gravstrap" icon_type="fontawesome" icon="facebook"][/g-link]
        [g-link url="https://twitter.com/gravstrap" icon="twitter"][/g-link]
        [g-link url="https://github.com/giansi/gravstrap" icon="github"][/g-link]
    [/g-navbar-menu]
[/g-navbar]

[g-footer-one name="footer" render=false]
[g-section name="credits"]

This website is made with [Grav CMS](http://getgrav.org/) and it is powerd by [Gravstrap Theme](http://diblas.net/themes/gravstrap-theme-to-start-grav-cms-site-with-bootstrap-support/) and [Gravstrap Plugin](http://diblas.net/plugins/use-bootstrap-elements-in-the-grav-cms-way/)

[/g-section]

[g-section name="copyright"]Joe Bloggs[/g-section]
[g-section name="license"]MIT License[/g-section]

[/g-footer-one]